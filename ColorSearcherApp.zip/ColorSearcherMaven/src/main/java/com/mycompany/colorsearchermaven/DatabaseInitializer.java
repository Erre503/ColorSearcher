/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.colorsearchermaven;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Erre
 */
public class DatabaseInitializer {
    
    public static void initializeDatabase(ColorSearcherImplementation dbManager) {
          String projectDir = System.getProperty("user.dir");
        // Construct the path to the SQL file
        Path sqlFilePath = Paths.get(projectDir, "src", "main", "java","com","mycompany", "colorsearchermaven", "schema.sql");
        Connection connection = dbManager.getConnection();
        try {
            // Read the SQL file content
            String sql = new String(Files.readAllBytes(sqlFilePath));
            connection.createStatement().execute(sql);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseInitializer.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
