/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.colorsearchermaven;

public class ColorData {
    private int r, g, b;
    private String rgb, cmyk, pantone;

    public ColorData(int r, int g, int b, String rgb, String cmyk) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.rgb = rgb;
        this.cmyk = cmyk;
        this.pantone = pantone;
    }

    public int getR() {
        return r;
    }

    public int getG() {
        return g;
    }

    public int getB() {
        return b;
    }

    public String getRgb() {
        return rgb;
    }

    public String getCmyk() {
        return cmyk;
    }

    public String getPantone() {
        return pantone;
    }
}