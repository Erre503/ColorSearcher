/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.colorsearchermaven;

/**
 *
 * @author Erre
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Erre
 */
public class ColorSearcherImplementation{

    private Connection connection;
    
    public ColorSearcherImplementation(String dbPath)throws Exception {
        connection = DriverManager.getConnection("jdbc:h2:" + dbPath);
        System.out.println(connection.isClosed());
        
    }
   public Connection getConnection() {
        return connection;
    }
 public ColorData getColorData(String pantoneCode) {
        String query = "SELECT * FROM RALColors WHERE LOWER(ral_code) = LOWER(?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, pantoneCode);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String rgb = rs.getString("rgb_value");
                    String cmyk = rs.getString("cmyk_value");
                    
                    String[] rgbValues = rgb.split(",");
                    int r = Integer.parseInt(rgbValues[0].trim());
                    int g = Integer.parseInt(rgbValues[1].trim());
                    int b = Integer.parseInt(rgbValues[2].trim());
                    return new ColorData(r, g, b, rgb, cmyk);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    
    
}
