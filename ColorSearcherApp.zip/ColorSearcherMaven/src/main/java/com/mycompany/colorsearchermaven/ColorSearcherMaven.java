/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.colorsearchermaven;

import javax.swing.SwingUtilities;

/**
 *
 * @author Erre
 */
public class ColorSearcherMaven {

public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {

                // Configura i dettagli della connessione al database

                String dbPath = "./database/ralcolors";
                try {
                    
                // Stabilisce la connessione
                    
                    ColorSearcherImplementation dbManager = new ColorSearcherImplementation(dbPath);
                    

                    System.out.println("no fucking way");

                    // Inizializza il database
                    DatabaseInitializer.initializeDatabase(dbManager);

                    // Crea e mostra l'interfaccia grafica
                    
                    ColorSearcherGUI gui = new ColorSearcherGUI(dbManager);
                    
                    DatabaseInitializer.initializeDatabase(dbManager);
                    
                    gui.setVisible(true);
                }
                catch(Exception e){
                    System.out.println(e);
                }
                

            }
        });
    }
    
}
