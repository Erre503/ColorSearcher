/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.colorsearchermaven;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 *
 * @author Erre
 */
public class DatabaseInitializer {
    private static final Logger LOGGER = Logger.getLogger(DatabaseInitializer.class.getName());
    public static void initializeDatabase(ColorSearcherImplementation dbManager) {
        try (InputStream inputStream = DatabaseInitializer.class.getClassLoader().getResourceAsStream("schema.sql")) {

            if (inputStream == null) {
                LOGGER.severe("Error: schema.sql file not found in JAR resources.");
                return;
            }

            // Read the SQL file content
            String sql = new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);

            // Execute the SQL to initialize the database
            Connection connection = dbManager.getConnection();
            connection.createStatement().execute(sql);

        } catch (SQLException e) {
            LOGGER.severe("Database error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            LOGGER.severe("Error reading or executing schema.sql: " + e.getMessage());
            e.printStackTrace();
        }
    }
}


